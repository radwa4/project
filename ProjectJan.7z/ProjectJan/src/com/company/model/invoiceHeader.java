package com.company.model;

import com.opencsv.CSVReader;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class invoiceHeader<InvoiceLine> {

    int invoiceNum;
    String invoiceDate;
    String customerName;

    static List<String> InvoiceLines = new ArrayList<>();

    public static void setInvoiceLines(List<String> invoiceLines) {
        InvoiceLines = invoiceLines;

    }

    public static void printInvoiceLines() {
        for (int i = 0; i < InvoiceLines.size(); i++) {
            System.out.print(InvoiceLines.get(i) + " , ");
        }
        System.out.println();
    }


}




