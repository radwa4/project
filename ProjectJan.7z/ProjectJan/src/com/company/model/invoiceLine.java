package com.company.model;

public class invoiceLine {

    String itemName;
    String itemPrice;
    String count;


    public static void setItemName(String itemName) {
        itemName = itemName;
    }

    public static void setItemPrice(String itemPrice) { itemPrice = itemPrice;
    }

    public static void setCount(String count) {
        count = count;
    }




}
