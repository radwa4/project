package com.company.view;

import com.company.model.invoiceHeader;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PrintSalesInvoice {

    private static final String COMMA_DELIMITER = ",";


    public static void PrintSalesInvoice(String filePath) throws FileNotFoundException {
        List<List<String>> records = new ArrayList<>();
        File file = new File(filePath);
        Scanner scanner = new Scanner(file);
        {
            while (scanner.hasNextLine()) {
                for (int i = 1; i < 3; i++) {
                    System.out.println("Invoice Num" + i + " :{");
                    records.add(getRecordFromLine(scanner.nextLine()));
                    invoiceHeader.printInvoiceLines();
                    readInvoiceLine("src/com/company/resources/invoiceLine.csv");
                    System.out.println(" }");
                }

            }
        }

    }


    private static List<String> getRecordFromLine(String line) {

        List<String> values = new ArrayList<String>();
        try (Scanner rowScanner = new Scanner(line)) {
            rowScanner.useDelimiter(COMMA_DELIMITER);
            while (rowScanner.hasNext()) {
                values.add(rowScanner.next());

            }

        }
        invoiceHeader.setInvoiceLines(values);

        return values;

    }


    public static void readInvoiceLine(String filePath) throws FileNotFoundException {
        List<List<String>> records = new ArrayList<>();
        File file = new File(filePath);
        Scanner scanner = new Scanner(file); {
            while (scanner.hasNextLine()) {


                    records.add(getRecordFromLine(scanner.nextLine()));
            }
            System.out.println(records);



        }
}}